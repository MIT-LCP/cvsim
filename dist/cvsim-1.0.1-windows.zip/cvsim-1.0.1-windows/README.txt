# Running CVSim



1. Install JRE 1.8.



2. From your terminal (cmd), navigate to this directory and type:

    run-cvsim.bat



3. Select the 6- or 21-compartment model and click OK.



4. See the CVSim home page, http://physionet.org/physiotools/cvsim/, for
 further details.

# Distribution 1.0.1 Windows

This package was compiled using:

```
java version "1.8.0_161"
Java(TM) SE Runtime Environment (build 1.8.0_161-b12)
Java HotSpot(TM) 64-Bit Server VM (build 25.161-b12, mixed mode)

Windows 10
```
