# Running CVSim

1. Install JRE 1.8.

2. Type
     ./run-cvsim

3. Select the 6- or 21-compartment model and click OK.

4. See the CVSim home page, http://physionet.org/physiotools/cvsim/, for
   further details.


# Distribution 1.0.1 Linux

This package was compiled using:

```
openjdk version "1.8.0_151"
OpenJDK Runtime Environment (build 1.8.0_151-8u151-b12-0ubuntu0.16.04.2-b12)
OpenJDK 64-Bit Server VM (build 25.151-b12, mixed mode)
```
