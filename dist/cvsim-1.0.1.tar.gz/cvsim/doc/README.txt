The doc/ directory contains the project documentation for the CVSim
GUI project. The demos/ directory contains a series of Flash demos
which demonstrate how to use the software. The devel_guide directory
contains the CVSim GUI Developer's Guide for programmers who wish to
continue work on the project.
