The demos/ directory contains a website with a series of Flash demos
which demonstrate how to use the CVSim GUI software. The demos were
created using an open-source program called DebugMode Wink
(www.debugmode.com/wink). The demos are based on versions 1.3 and 1.5
of the CVSim GUI.
