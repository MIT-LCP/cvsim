The developers_guide directory contains the Latex source and pdf
output for the CVSim GUI Developer's Guide. The Developer's Guide is
intended for programmers who want to continue work on the project. It
is not a user manual. For information on how to use the CVSim GUI, see
the demos/ directory.

