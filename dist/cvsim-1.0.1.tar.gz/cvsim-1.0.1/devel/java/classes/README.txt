# Running CVSim

1. Install JRE 1.8.

2. Type
     ./run-cvsim

3. Select the 6- or 21-compartment model and click OK.

4. See the CVSim home page, http://physionet.org/physiotools/cvsim/, for
   further details.
