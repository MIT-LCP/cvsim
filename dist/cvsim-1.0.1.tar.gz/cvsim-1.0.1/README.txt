CVSim Sources

Release 1.0.1	Jan 2018

This directory contains two subdirectories:

     devel/ contains all the project code
     doc/ contains all the project documentation

See devel/00README for quick start instructions;  for more details, see
the Developer's Guide in the doc subdirectory.

The latest release of CVSim can always be downloaded from:

     http://physionet.org/physiotools/cvsim/
