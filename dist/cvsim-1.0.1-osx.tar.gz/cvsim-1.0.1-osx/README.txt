# Running CVSim

1. Install JRE 1.8.

2. Type
     ./run-cvsim

3. Select the 6- or 21-compartment model and click OK.

4. See the CVSim home page, http://physionet.org/physiotools/cvsim/, for
   further details.


# Distribution 1.0.1 OSX

This package was compiled using:

```
java version "1.8.0_101"
Java(TM) SE Runtime Environment (build 1.8.0_101-b13)
Java HotSpot(TM) 64-Bit Server VM (build 25.101-b13, mixed mode)

OSX 10.11
```
